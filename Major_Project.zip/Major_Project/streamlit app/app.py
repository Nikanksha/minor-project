## import necessary libraries
import streamlit as st
import numpy as np
import pandas as pd
import pickle

## load classifier_model and dataset
model = pickle.load(open('rfc_model1.pkl','rb'))
df_imp = pickle.load(open('df_imp1.pkl','rb'))

## Set title
st.title("Credit Card Risk Prediction Model")

### Inputs

## STATUS
status = st.selectbox('STATUS', df_imp['STATUS'].unique())

## INCOME
income = st.selectbox('INCOME', df_imp['INCOME'].unique())

## OCCUPATION
occupation = st.selectbox('OCCUPATION', df_imp['OCCUPATION'].unique())

## PROPERTY
property = st.selectbox('PROPERTY', df_imp['PROPERTY'].unique())


## Make prediction
query = np.array([[status,income,occupation,property]])
prediction = model.predict(query)
if st.button("Predict Status of Credit Card User"):
    if prediction==1:
        st.title("Good Client")
    else:
        st.title('Bad Client')










