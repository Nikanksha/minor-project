import pickle
import streamlit as st
import requests

def recommend(book):
    book_index = books[books['original_title'] == book].index[0]
    distances = similarity[book_index]
    books_list = sorted(list(enumerate(distances)), reverse=True, key=lambda x: x[1])[1:6]
    recommended_book_names = []

    for i in books_list:
        #print(content_data.iloc[i[0]].original_title)
        book_title = books.iloc[i[0]].original_title
        recommended_book_names.append(books.iloc[i[0]].original_title)
    return recommended_book_names




st.header('Book Recommender System')
books = pickle.load(open('book_list.pkl','rb'))
similarity = pickle.load(open('similarity.pkl','rb'))

book_list = books['original_title'].values
selected_book = st.selectbox(
    "Type or select a book from the dropdown",
    book_list
)

if st.button('Show Recommendation'):
    recommended_book_names = recommend(selected_book)
    col1, col2, col3, col4, col5 = st.columns(5)
    with col1:
        st.text(recommended_book_names[0])

    with col2:
        st.text(recommended_book_names[1])


    with col3:
        st.text(recommended_book_names[2])

    with col4:
        st.text(recommended_book_names[3])

    with col5:
        st.text(recommended_book_names[4])


